from django.shortcuts import render
from student.models import Student
from attendance.models import Attendance
# Create your views here.

def attendance(request):
    ob=Student.objects.all()
    context = {
        'k': ob,
    }
    if request.method=="POST":
        obj=Attendance()
        obj.s_id=request.POST.get('students')
        obj.status=request.POST.get('att')
        obj.date=request.POST.get('d1')
        obj.time=request.POST.get('t1')
        obj.save()
    return render(request,'attendance/attendance.html',context)

def atte_view(request):
    obj=Attendance.objects.all()
    context={
        'x':obj
    }
    return render(request,'attendance/view_attendance.html',context)



def parent_view_atten(request):
    # ss=request.session["uid"]
    obj=Attendance.objects.all()
    context={
        'x':obj
    }
    return render(request,'attendance/view_parent.html',context)