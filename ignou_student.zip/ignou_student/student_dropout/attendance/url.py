from django.conf.urls import url
from attendance import views

urlpatterns=[
    url('attendance/', views.attendance),
    url('ass_view/',views.atte_view),
    # url('att_pre/(?P<idd>\w+)', views.att_present, name='att_present'),
    # url('te_ab/(?P<idd>\w+)', views.att_absent, name='att_absent'),
    url('prnt_view/',views.parent_view_atten),
    ]