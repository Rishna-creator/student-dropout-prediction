from django.http import HttpResponseRedirect
from django.shortcuts import render
from student.models import Student
from classes.models import Classes

# Create your views here.
def student(request):
    obb=Classes.objects.filter(status='approved')
    context = {
        'v': obb,
        # 'msg':obk
    }
    obk=""
    if request.method=='POST':
        obj=Student()
        obj.name=request.POST.get('n1')
        obj.email= request.POST.get('em')
        obj.address= request.POST.get('ad')
        obj.phone_no=request.POST.get('p1')
        obj.gender=request.POST.get('gen')
        obj.c_id=request.POST.get('c')
        obj.save()
        obk="User"

    return render(request,'student/student_reg.html',context)

def student_view(request):
    obj=Student.objects.all()
    context={
        'x':obj
    }
    return render(request,'student/student_view.html',context)

def std_approve(request,idd):
    obj=Student.objects.get(s_id=idd)
    obj.status='Approved'
    obj.save()
    return student_view(request)


def std_reject(request,idd):
    obj=Student.objects.get(s_id=idd)
    obj.status='Rejected'
    obj.save()
    return student_view(request)

def std_update(request,idd):
    obj=Student.objects.get(s_id=idd)
    context={
        'x':obj
    }
    if request.method=="POST":
        obj=Student.objects.get(s_id=idd)
        obj.name = request.POST.get('n1')
        obj.gender = request.POST.get('gen1')
        obj.email = request.POST.get('em')
        obj.address = request.POST.get('ad')
        obj.phone_no = request.POST.get('p1')
        obj.p_id = '1'
        obj.save()
        return student_view(request)
    return render(request,'student/student_update.html',context)