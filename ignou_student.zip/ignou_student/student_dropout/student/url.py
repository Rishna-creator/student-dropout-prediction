from django.conf.urls import url
from student import views

urlpatterns=[
    url('student/',views.student),
    url('student_vw/',views.student_view),
    url('std_approve/(?P<idd>\w+)', views.std_approve, name='std_approve'),
    url('std_reject/(?P<idd>\w+)', views.std_reject, name='std_reject'),
    url('std_update/(?P<idd>\w+)', views.std_update, name='std_update')

]