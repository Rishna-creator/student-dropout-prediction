from django.db import models
# from parent.models import Parent
# Create your models here.

class Student(models.Model):
    s_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=50)
    address = models.CharField(max_length=50)
    phone_no = models.CharField(max_length=10)
    email = models.CharField(max_length=50)
    status = models.CharField(max_length=50)
    gender = models.CharField(max_length=25)
    c_id = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'student'
