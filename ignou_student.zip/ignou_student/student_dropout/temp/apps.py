from django.apps import AppConfig


class TempConfig(AppConfig):
    name = 'temp'
