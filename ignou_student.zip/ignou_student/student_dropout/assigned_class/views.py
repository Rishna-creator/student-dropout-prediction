from django.shortcuts import render
from classes.models import Classes
from teacher.models import Teacher
from assigned_class.models import AssignedClass


# Create your views here.

def assined_class(request):
    ob=Teacher.objects.all()
    obb=Classes.objects.all()
    context = {
        'x': ob,
        'y': obb,

    }
    if request.method=="POST":
        obj=AssignedClass()
        obj.c_id=request.POST.get('c1')
        obj.t_id=request.POST.get('t1')
        obj.save()
        context = {
            'x': ob,
            'y': obb,

        }
    return render(request,'assigned_class/assigned_class.html',context)

def view_ass(request):
    ss=request.session["uid"]
    obj = AssignedClass.objects.filter(t_id=ss)
    context = {
        'x': obj
    }
    return render(request, 'assigned_class/view_assigned_class.html', context)
