from django.db import models
from classes.models import Classes
from teacher.models import Teacher

# Create your models here.
class AssignedClass(models.Model):
    as_id = models.AutoField(primary_key=True)
    # c_id = models.IntegerField()
    c=models.ForeignKey(Classes,to_field='c_id',on_delete=models.CASCADE)
    # t_id = models.IntegerField()
    t=models.ForeignKey(Teacher,to_field='t_id',on_delete=models.CASCADE)

    class Meta:
        managed = False
        db_table = 'assigned_class'
