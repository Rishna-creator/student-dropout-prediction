from django.apps import AppConfig


class AssignedClassConfig(AppConfig):
    name = 'assigned_class'
