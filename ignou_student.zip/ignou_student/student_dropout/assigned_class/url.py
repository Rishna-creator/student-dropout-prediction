from django.conf.urls import url
from assigned_class import views

urlpatterns=[
    url('assigned_class/',views.assined_class),
    url('ass_view/',views.view_ass)
    
    ]