from django.http import HttpResponse
from django.shortcuts import render
from classes.models import Classes
from teacher.models import Teacher
from django.db.models import Q
# Create your views here.
def reg_classes(request):
    obk = ""
    if request.method == 'POST':
        a = request.POST.get('c1')
        b = request.POST.get('d1')
        obb = Classes.objects.filter(Q(class_name=a,division=b))
        if len(obb) > 0:
            obk = "User"
        else:
            obj=Classes()
            obj.class_name=request.POST.get('c1')
            obj.division= request.POST.get('d1')
            obj.save()
            obk = "Succefully Registered"
    context = {
         'msg': obk
    }
    return render(request,'classes/reg_classes.html',context)

def classes_view(request):
    obj=Classes.objects.all()
    context={
        'x':obj
    }
    return render(request,'classes/view_classes.html',context)


def cl_approve(request,idd):
    obj=Classes.objects.get(c_id=idd)
    obj.status='Approved'
    obj.save()
    return classes_view(request)

def cl_reject(request,idd):
    obj=Classes.objects.get(c_id=idd)
    obj.status='Rejected'
    obj.save()
    return classes_view(request)

