from django.conf.urls import url
from classes import views
urlpatterns=[
    url('classes/', views.reg_classes),
    url('classes_vw/',views.classes_view),
    url('cl_approve/(?P<idd>\w+)', views.cl_approve, name='cl_approve'),
    url('cl_reject/(?P<idd>\w+)', views.cl_reject, name='cl_reject'),

]