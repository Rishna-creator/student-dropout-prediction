from django.db import models
# Create your models here.
class Classes(models.Model):
    c_id = models.AutoField(primary_key=True)
    class_name = models.CharField(max_length=50)
    division = models.CharField(max_length=50)
    status = models.CharField(max_length=50)

    class Meta:
        managed = False
        db_table = 'classes'
