from django.shortcuts import render
from result.models import Result
from student.models import Student
from classes.models import Classes
from result.models import InternalMark
# Create your views here.
def result(request):
    obj=Student.objects.all()
    ob=Classes.objects.all()
    context={
        'ok':obj,
        'k':ob
    }
    if request.method=='POST':
        obj=Result()
        obj.s_id=request.POST.get('student_name')
        # obj.name=request.POST.get('student_name')
        obj.c_id= request.POST.get('classes')
        obj.total_mark= request.POST.get('tm')
        obj.result=request.POST.get('r1')
        obj.remark=request.POST.get('rmk')
        obj.save()
    return render(request,'result/frd_result.html',context)

def result_view(request):
    obj=Result.objects.all()
    context={
        'x':obj
    }
    return render(request,'result/view_result.html',context)

def adresult_view(request):
    obj=Result.objects.all()
    context={
        'x':obj
    }
    return render(request,'result/ad_view_result.html',context)


def internal(request):
    ss=request.session["uid"]
    obb=Student.objects.all()
    context={
        'ss':obb
    }
    if request.method=='POST':
        obj=InternalMark()
        obj.s_id=request.POST.get('snm')
        obj.t_id=ss
        obj.internal_mark=request.POST.get('im')
        obj.save()
    return render(request,'result/internal_mark.html',context)


def intview(request):
    obj=InternalMark.objects.all()
    context={
        'x':obj
    }
    return render(request,'result/v_internal.html',context)


def vr(request):
    obj=Result.objects.all()
    context={
        'x':obj
    }
    return render(request,'result/vr.html',context)
