from django.conf.urls import url
from result import views

urlpatterns=[
    url('res/',views.result),
    url('vw_result/',views.result_view),
    url('adviewresult/',views.adresult_view),
    url('internal/',views.internal),
    url('vi/',views.intview),
    url('rr/',views.vr)
]