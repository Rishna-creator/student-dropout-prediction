from django.db import models
from student.models import Student
from classes.models import Classes
# Create your models here.
class Result(models.Model):
    rs_id = models.AutoField(primary_key=True)
    # s_id = models.IntegerField()
    s=models.ForeignKey(Student,to_field='s_id',on_delete=models.CASCADE)
    # name = models.CharField(max_length=50)
    # c_id = models.IntegerField()
    c = models.ForeignKey(Classes, to_field='c_id', on_delete=models.CASCADE)
    total_mark = models.CharField(db_column='total mark', max_length=50)  # Field renamed to remove unsuitable characters.
    result = models.CharField(max_length=50)
    remark = models.CharField(max_length=25)


    class Meta:
        managed = False
        db_table = 'result'

from teacher.models import Teacher
class InternalMark(models.Model):
    inter_id = models.AutoField(primary_key=True)
    # s_id = models.IntegerField()
    s=models.ForeignKey(Student,to_field='s_id',on_delete=models.CASCADE)
    # t_id = models.IntegerField()
    t=models.ForeignKey(Teacher,to_field='t_id',on_delete=models.CASCADE)
    internal_mark = models.CharField(max_length=25)

    class Meta:
        managed = False
        db_table = 'internal_mark'


