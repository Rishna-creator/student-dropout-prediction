from django.conf.urls import url
from parent import views

urlpatterns=[
    url('parent/',views.parent)

]