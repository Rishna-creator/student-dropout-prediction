from django.shortcuts import render
from parent.models import Parent
from login.models import Login
from student.models import Student
# Create your views here.

def parent(request):
    ob=Student.objects.all()
    context = {
        'k': ob
    }
    if request.method=='POST':
        obj=Parent()
        obj.s_id=request.POST.get('students')
        obj.name=request.POST.get('n1')
        obj.password=request.POST.get('pass')
        obj.contact_no=request.POST.get('c1')
        obj.email=request.POST.get('e1')
        obj.address=request.POST.get('add')
        obj.save()


        ob = Login()
        ob.username = request.POST.get('n1')
        ob.password = request.POST.get('pass')
        ob.type = 'parent'
        ob.u_id=obj.p_id
        ob.save()
    return render(request,'parent/parent_reg.html',context)