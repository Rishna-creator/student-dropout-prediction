from django.db import models
from student.models import Student
# Create your models here.
class Parent(models.Model):
    p_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=50)
    password = models.CharField(max_length=50)
    contact_no = models.CharField(max_length=15)
    email = models.CharField(max_length=50)
    # s_id = models.IntegerField()
    s = models.ForeignKey(Student, to_field='s_id', on_delete=models.CASCADE)
    address = models.CharField(max_length=25)
    contact_no = models.CharField(max_length=10)


    class Meta:
        managed = False
        db_table = 'parent'
