from django.apps import AppConfig


class ParentConfig(AppConfig):
    name = 'parent'
