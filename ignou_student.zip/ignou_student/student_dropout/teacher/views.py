from django.http import HttpResponseRedirect
from django.shortcuts import render
from teacher.models import Teacher
from login.models import Login

# Create your views here.
def teacher(request):
    obk=""
    if request.method=='POST':
        obj=Teacher()
        obj.name=request.POST.get('n1')
        obj.password=request.POST.get('pass')
        obj.email= request.POST.get('em')
        obj.address= request.POST.get('ad')
        obj.phone=request.POST.get('p1')
        obj.qualification=request.POST.get('q1')
        obj.gender=request.POST.get('gen')
        obj.save()

        ob=Login()
        ob.username=request.POST.get('n1')
        ob.password=request.POST.get('pass')
        ob.type='teacher'
        ob.u_id=obj.t_id
        ob.save()
        obk="User"
    context={
        'msg':obk
    }
    return render(request,'teacher/teacher_reg.html',context)

def teacher_view(request):
    obj=Teacher.objects.all()
    context={
        'x':obj
    }
    return render(request,'teacher/teacher_view.html',context)

def te_approve(request,idd):
    obj=Teacher.objects.get(t_id=idd)
    obj.status='Approved'
    obj.save()
    return teacher_view(request)

def te_reject(request,idd):
    obj=Teacher.objects.get(t_id=idd)
    obj.status='Rejected'
    obj.save()
    return teacher_view(request)

def te_update(request,idd):
    obj=Teacher.objects.get(t_id=idd)
    context={
        'x':obj
    }
    if request.method=="POST":
        obj=Teacher.objects.get(t_id=idd)
        obj.name = request.POST.get('n1')
        obj.email = request.POST.get('em')
        obj.address = request.POST.get('ad')
        obj.phone = request.POST.get('p1')
        obj.qualification = request.POST.get('q1')
        obj.save()
        return update_profile(request)
    return render(request,'teacher/teacher_update.html',context)

def update_profile(request):
    ss=request.session["uid"]
    obj=Teacher.objects.filter(t_id=ss)
    context={
        'x':obj
    }
    return render(request,'teacher/update_profile.html',context)

def te_delete(request,idd):
    obj=Teacher.objects.get(t_id=idd).delete()
    return teacher_view(request)