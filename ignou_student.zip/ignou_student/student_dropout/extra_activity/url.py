from django.conf.urls import url
from extra_activity import views

urlpatterns=[
    url('ex/',views.ex_activity),
    url('view/',views.ex_view)
    ]