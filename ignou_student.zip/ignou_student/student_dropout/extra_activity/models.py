from django.db import models
from  student.models import Student
# Create your models here.
class ExtraActivity(models.Model):
    e_id = models.AutoField(primary_key=True)
    activity = models.CharField(max_length=50)
    # s_id = models.IntegerField()
    s=models.ForeignKey(Student,to_field='s_id',on_delete=models.CASCADE)
    class Meta:
        managed = False
        db_table = 'extra_activity'

