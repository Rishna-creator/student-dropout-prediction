from django.apps import AppConfig


class ExtraActivityConfig(AppConfig):
    name = 'extra_activity'
