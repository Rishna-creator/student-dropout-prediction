from django.shortcuts import render
from extra_activity.models import ExtraActivity
from student.models import Student
# Create your views here.
def ex_activity(request):
    ob=Student.objects.all()
    context={
        'k':ob
    }
    if request.method=='POST':
        obj=ExtraActivity()
        obj.s_id=request.POST.get('students')
        obj.activity=request.POST.get('a1')
        obj.save()
    return render(request,'extra_activity/extra_activity.html',context)


def ex_view(request):
    obj=ExtraActivity.objects.all()
    context={
        'x':obj
    }
    return render(request,'extra_activity/view_extra.html',context)