from django.conf.urls import url
from question import views

urlpatterns=[
    url('qstn/',views.predict),
    url('dd/',views.drpres)
]