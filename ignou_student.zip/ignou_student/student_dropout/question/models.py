from django.db import models
from student.models import Student
# Create your models here.
class Dropout(models.Model):
    dropout_id = models.AutoField(primary_key=True)
    # s_id = models.IntegerField()
    s=models.ForeignKey(Student,to_field='s_id',on_delete=models.CASCADE)
    res = models.CharField(max_length=150)

    class Meta:
        managed = False
        db_table = 'dropout'

